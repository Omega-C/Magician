import flask, os
from MagnusBurd import *
app=flask.Flask(__name__)
pathr=lambda *args:os.sep.join(args)
#pkill -9 python

@app.route("/")
def home():
	with open(pathr("website","main.html"),"r") as page:
		dat=page.read()
	return(dat)

@app.route("/files/<path>")
def extraneousGet(path):
	name=path
	print(name)
	file=pathr("website",*name.split("/"))
	with open(file,"rb") as page:
		dat=page.read()
	return(dat)

@app.route("/files/database/<path>")
def datGet(path):
	name=path
	print(name)
	file=pathr("website","database",name)
	with open(file,"rb") as page:
		dat=page.read()
	return(dat)

@app.route("/api",methods=["GET","POST"])
def api():
	endresp=None
	query=dict(flask.request.args)
	"""if {"session","text","from","responder"}.intersection(set(query.keys()))=={"session","text","from","responder"}:
		response,prompt=Sessions[query["session"]].ask(Interaction(query["from"],query["text"]),query["responder"],retPrompt=True)
		sendResp={"From":response.fro,"Text":response.data,"Prompt":prompt}
		endResp=sendResp
		print(prompt)
	elif {"session","back"}.intersection(set(query.keys()))=={"session","back"}:
		try:
			Sessions[query["session"]].unprocess()
			endResp={}
		except:
			endResp={"Type":"Error","Reason":"Uncatched unprocessing error."}
	elif {"session","save"}.intersection(set(query.keys()))=={"session","save"}:
		Sessions[query["session"]].save(pathr("website","database",query["save"]+".conversation"))
		endResp={}
	else:
		endResp={"Type":"Error","Reason":"Lacking required parameters."}
	return(endResp)"""


def init():
	pass

def start(*args,**kwargs):
	app.run(*args,**kwargs)

if __name__=="__main__":
	init()
	start()
