/*
message has props of profile, text.
Messages contains a list of messages.
Settings is a dropdown when clicked list of settings form maybe?
the input box is another component that appnds a message to the end of the messages in the messages component.
UserID, 10 hexidecimal characters, store in db
*/

function bottomMessages() {
	let messageBox=document.getElementById("messages");
	messageBox.scrollTop=messageBox.scrollHeight-messageBox.clientHeight;
}

class User {
	constructor(name,identification,magic=false,active=true,pfp="/images/default.jpeg") {//might not stay later, just a class for user information
		this.name=name;
		this.id=identification;
		this.magic=magic;
		this.pfp=pfp;
		this.active=active;
		this.status="inactive"
		if (this.magic) {this.status="AIStatus"}
		if (this.active) {this.status="active"}
	}
	returnType() {
		if (Session.SelectedUser.id==this.id) {return("textSent")}
		if (this.magic) {return("textAI")}
		return("textUser")
	}
	verify() {}//use some db verification I geuss
	static load() {} //use other stuff
	static getById() {}
}

class Session {
	static messages=[];
	static SelectedUser=new User("Simone","0000000000",false,true,"https://media.tenor.com/images/57a66f64fb43014eb6ecb45897d7e5dd/tenor.gif");
	static Members=[new User("Dave","0000000001",false,false),new User("AI","0000000002",true,false,"https://pngimg.com/uploads/toaster/toaster_PNG46.png")];//temporary thing, will autoload
	static settings={};
	static addMessage(message) {
		Session.messages.push(message);
		this.setState((state)=>{return({...state,messages:[...state.messages,message],messageConverts:[...state.messageConverts,this.construct(message)]})})
	}
}

class MessageConstruct {
	constructor(user,message,date=null) {
		if (date==null){
			this.date=new Date()
			this.date=this.date.getDate()
		}
		else {
			this.date=date
		}
		this.user=user
		this.message=message
		this.type=user.returnType()
	}
	userID() {
		return(this.user.id);
	}
	construct(previousID) {
		return(<Message user={this.user} previousID={previousID} type={this.type}>{this.message}</Message>);
	}
}

class Message extends React.Component {
	constructor(props) {
		super(props);
		this.state={message:props.children,user:props.user,prevID:props.previousID,type:props.type};
	}
	render() {
		let image=<img className={this.state.user.status} onClick={(event)=>{return(false)}} src={this.state.user.pfp} alt={`${this.state.user.name}:${this.state.user.id}`}></img>
		let title=<div className="title">{this.state.user.name}</div>
		let text=<div className="internalText">{this.state.message}</div>
		if (this.state.prevID!=this.state.user.id) {
			if (this.state.type=="textSent"){
				return(<div className={this.state.type}>{image}{title}<br/>{text}</div>);
			}
			return(<div className={this.state.type}>{image}{title}<br/>{text}</div>);
		}
		return(<div className={this.state.type}>{text}</div>);
	}
}

class Messages extends React.Component {
	constructor(props){
		super(props);
		this.state={messages:Session.messages,messageConverts:this.mapConstruct(Session.messages),prevID:"_"}
	}
	componentDidMount() {
		Session.addMessage=Session.addMessage.bind(this)
	}
	construct(message) {
		let messageNew=message.construct(this.state.prevID);
		this.setState((state)=>{return({...state,prevID:message.userID()})})
		return(messageNew)
	}
	mapConstruct(messages) {//complete re-construct
		let previousID="_";
		let MessageTags=[];
		for (let index=0;index<messages.length;index++) {
			MessageTags.push(messages[index].construct(previousID));
			previousID=messages[index].userID();
		}
		this.setState((state)=>{return({...state,prevID:previousID})})
		return(MessageTags);
	}
	render() {
		return(this.state.messageConverts);
	}
}

class InputBox extends React.Component {
	constructor(props) {
		super(props);
	}
	constructMessage() {
		let text=document.getElementsByClassName("textbox")[0].textContent.trim()
		if (text!="") {
			document.getElementsByClassName("textbox")[0].textContent=""
			return(new MessageConstruct(Session.SelectedUser,text))
		}
		return(null)
	}
	sendMessage(message) {
		//API stuff here
		if (message!=null) {
			Session.addMessage(message)
			console.log("added!")
		}
	}
	replaceWhitespace(event) {
		if (event.key==="Enter"){
			document.execCommand('insertLineBreak');
			event.preventDefault()
		}
	}
	render() {
		return(
			<div className="inputForm">
				<div contentEditable={true} onKeyDown={this.replaceWhitespace} className="textbox"></div>
				<button className="send" onClick={()=>{this.sendMessage(this.constructMessage())}}><div className="arrow"></div></button>
			</div>);
	}
}

ReactDOM.render(<InputBox/>, document.getElementById("input"))
ReactDOM.render(<Messages/>, document.getElementById("messages"))

Session.addMessage(new MessageConstruct(Session.SelectedUser,"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean id."))
Session.addMessage(new MessageConstruct(Session.SelectedUser,"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris porttitor felis risus, et tincidunt lorem bibendum dictum. Morbi placerat augue nec ultrices varius. Aenean cursus varius risus. Nulla efficitur in."))
Session.addMessage(new MessageConstruct(Session.Members[0],"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec et lobortis arcu, eget venenatis magna.\nSuspendisse consectetur nunc nec interdum imperdiet. Nunc at justo nibh. Cras sit amet sapien at."))
Session.addMessage(new MessageConstruct(Session.Members[1],"Lorem ipsum dolor sit amet,\nconsectetur adipiscing\nelit."))
Session.addMessage(new MessageConstruct(Session.Members[1],"also dale, can I know what you did? I am typing sample text to have some text to use in hyphenationopertunities Please do something responsible for this stuff maybe please?"))
Session.addMessage(new MessageConstruct(Session.SelectedUser,"Lorem ipsum dolor sit amet,\nconsectetur adipiscing elit. Mauris porttitor felis risus, et tincidunt lorem bibendum dictum. Morbi placerat augue ultrices varius. Aenean cursus varius risus. Nulla efficitur in."))
Session.addMessage(new MessageConstruct(Session.SelectedUser,"Lorem ipsum dolor sit amet,\nconsectetur adipiscing elit. Mauris porttitor felis risus, et tincidunt lorem bibendum dictum. Morbi placerat augue ultrices varius. Aenean cursus varius risus. Nulla efficitur in."))
Session.addMessage(new MessageConstruct(Session.SelectedUser,"Lorem ipsum dolor sit amet,\nconsectetur adipiscing elit. Mauris porttitor felis risus, et tincidunt lorem bibendum dictum. Morbi placerat augue ultrices varius. Aenean cursus varius risus. Nulla efficitur in."))
Session.addMessage(new MessageConstruct(Session.SelectedUser,"Lorem ipsum dolor sit amet,\nconsectetur adipiscing elit. Mauris porttitor felis risus, et tincidunt lorem bibendum dictum. Morbi placerat augue ultrices varius. Aenean cursus varius risus. Nulla efficitur in."))
Session.addMessage(new MessageConstruct(Session.SelectedUser,"Lorem ipsum dolor sit amet,consectetur adipiscing elit. Mauris\nporttitor felis risus, et tincidunt lorem bibendum dictum. Morbi placerat augue ultrices varius. Aenean cursus varius risus. Nulla efficitur in."))