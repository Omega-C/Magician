__import__("sys").path.append("..")
import flask, datetime, jwt
import MagnusBurd
from hiddenData import *
application=flask.Flask(__name__)

#pkill -9 python
#Immediatly phase out unsecure data upon first ability



def tokenize(username,password,expire=datetime.datetime.now()+datetime.timedelta(days=1),**kwargs):
	return(jwt.encode({"username":username,"password":password,**kwargs,"exp":expire},secretKey,algorithm="HS256"))

def tokenVerifier(bearerToken,ensuredata={}):
	try:
		data=jwt.decode(bearerToken,secretKey,algorithms=["HS256"])
		for key,val in ensuredata.items():
			if key not in data:
				return({"status":"Inconsistancy","note":"re-login, if error still appears, contact @MagicianDev"})
			if data[key]!=val:
				return({"status":"Inconsistancy","note":"re-login, if error still appears, contact @MagicianDev"})
		return({"status":"Verified","data":data})
	except jwt.ExpiredSignatureError:
		return({"status":"Expired","note":"login expire after 1 day, re-login"})
	except jwt.InvalidSignatureError:
		return({"status":"Invalid","note":"invalid token. If the error is gotten without user modification, inform @MagicianDev"})
	except Exception:
		return({"status":"UnknownError","note":"bring this alongside passed token to @MagicianDev"})

def getFile(name:str,defaultFile:str="files/error.html")->bytes:
	try:
		with open(name,"rb") as file:
			return(file.read())
	except FileNotFoundError:
		with open(defaultFile,"rb") as file:
			flask.abort(404)
			return(file.read())

def pullAI(filepath,key=None):
	if key!=None:
		return(MagnusBurd.Nucleus.loadEncrypted("",key,filepath))
	return(MagnusBurd.Nucleus.load("",filepath))

def createUser(userid,password,**kwargs):
	passwordHashed=MagnusBurd.Encryption.hash(password)#SHA256 with salt
	userBase[userid]={"passwordHash":passwordHashed,**kwargs}

def confirmUser(userid,password):
	if userid not in userBase:
		return(False)
	return(MagnusBurd.Encryption.confirmHash(userBase[userid]["passwordHash"],password))

def wrapBearer(func):
	bearerToken=flask.request.headers["Authorization"]
	#getTokenSomehow
	#Check if token valid
	#redirect to login if not valid or no token
	#return function with the parameter of bearer token

@application.errorhandler(404)
def notFound(err):
	return(getFile("files/error.html"))

@application.route("/")
def home():
	return(getFile("files/main.html"))

@application.route("/messages")
def messages():
	return(getFile("files/messages.html"))

@application.route("/login")
def login():
	return(getFile("files/login.html"))

@application.route("/<path>")
def route(path):
	return(getFile(f"files/{path}"))

@application.route("/chatBase/<path>")
def routechats(path):
	return(getFile(f"databaseFiles/chats/{path}"))

"""@application.route("/AIBase/<path>")
def route(path):
	return(getFile(f"databaseFiles/ai/{path}"))"""

@application.route("/images/<path>")
def routeimages(path):
	return(getFile(f"databaseFiles/images/{path}"))

"""@application.route("/api/ai",methods=["POST"])
def apia():
	headers=dict(flask.request.headers)
	body=flask.request.get_json(force=True)
	return({"from":"AI","text":["SampleText"]})"""

@application.route("/api/tokenauthentication",methods=["POST"])
def apib():
	body=flask.request.get_json(force=True)
	if "bearerToken" in body:
		return(tokenVerifier(body["bearerToken"]))
	return({"status":"MissingToken","note":"token is missing from input"})

@application.route("/api/tokencreation",methods=["POST"])
def apic():
	body=flask.request.get_json(force=True)
	if ("username" in body) and ("password" in body):
		if confirmUser(body["username"],body["password"]):
			return({"status":"OK","token":tokenize(body["username"],body["password"])})
		return({"status":"InvalidLogin","note":"login information is incorrect"})
	return({"status":"MissingLogin","note":"login information is not provided to the api, contact @MagicianDev"})

@application.route("/images/default.jpeg")
def imgdef():
	return(flask.send_file("files/defaultProfile.jpeg",mimetype="image/jpeg"))



def debug():
	pass

def applicationMain():
	application.run(host="0.0.0.0",port=80)



if __name__=="__main__":
	#createUser("username1","password1",status="default",username="Default")
	#print(userBase)
	applicationMain()
